package com.example.yok

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.Mauric)
        button.setOnClickListener {
            Intent(this, YokActivity2::class.java).also {
                startActivity(it)
            }
        }

        val button2 = findViewById<Button>(R.id.Sahara)
        button2.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("https://instagram.com/mauricalmdts_?igshid=YmMyMTA2M2Y=")
            startActivity(intent)

        }
    }

}